/**
 * Created by Administrator on 2016/10/27 0027.
 */
$(function () {
    $('.code_icon').click(function () {
        $(this).css('background-image','url(../images/getCode2.jpg)')
        console.log(111)
    });
});