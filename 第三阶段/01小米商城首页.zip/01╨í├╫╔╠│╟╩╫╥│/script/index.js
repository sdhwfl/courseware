$(function() {

  //购物车下拉
  $(".header_shop").hover(function() {
    $(".shop_updown").stop().slideDown();
  }, function() {
    $(".shop_updown").stop().slideUp();
  });
  //标题下拉菜单
  $(".title_nav").hover(function() {
    $(".nav_updown").stop().slideDown(50);
  }, function() {
    $(".nav_updown").stop().slideUp(50);
  });
  $(".nav_updown").hover(function() {
    $(".nav_updown").stop().slideDown();
  }, function() {
    $(".nav_updown").stop().slideUp(50);
  })

  //产品导航
  $('.banner_nav').hover(function() {
    $(".side-nav-container").show()
  }, function() {
    $(".side-nav-container").hide()
  })
  $(".side-nav-container").hover(function() {
    $(".side-nav-container").show()
  }, function() {
    $(".side-nav-container").hide()
  })

  //轮播图
  var groupNum = 0;
  var maxPage = $(".container .banner img").length;
  // 左右按钮
  $(".banner-btn").click(function() {
    console.log($(this).hasClass("banner_prev"))
    if ($(this).hasClass("banner_prev")) {
      groupNum--;
      groupNum = groupNum < 0 ? (groupNum + maxPage) : groupNum;
    } else {
      groupNum++;
      groupNum = groupNum % maxPage;
    }
    $(".banner img:eq(" + groupNum + ")").stop().fadeIn().siblings().stop().fadeOut();
    $(".banner_btn span:eq(" + groupNum + ")").addClass('circle').siblings().removeClass('circle');
  });
  // 点击点
  $(".banner_btn span").click(function() {
    var num = $(this).index();
    $(".banner img:eq(" + num + ")").stop().fadeIn().siblings().stop().fadeOut();
    $(this).addClass('circle').siblings().removeClass('circle');
  });

  //明星单品翻页
  $(".start_btnR .start_left").click(function() {
    $(".protects").animate({
      left: "0px"
    });
    $(this).addClass("active").siblings('span').removeClass("active");
  });
  $(".start_btnR .start_right").click(function() {
    if (!$(this).hasClass("active")) {
      $(".protects").animate({
        left: "-1226px"
      });
    }
    $(this).addClass("active").siblings('span').removeClass("active");
  });
  var num = 0;
  var timer3 = null;

  function setTimer3() {
    timer3 = setInterval(function() {
      num++
      num = num % 2;
      $(".protects").animate({
        left: -1226 * num + "px"
      });
    }, 3000);
  }

  $(".protects").hover(function() {
    clearInterval(timer3)
  }, setTimer3)

  //商品标签页
  $('.proPages a').mouseenter(function() {
    $(this).addClass('pageAct').siblings().removeClass('pageAct');
    $('.page:nth-child(' + ($(this).index() + 1) + ')').show().siblings().hide();
  });
});
