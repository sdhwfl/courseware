const mongoose = require("mongoose");
//用es6中的Promise来取代mongoose里集成的已经过时的promise
mongoose.Promise = Promise;
mongoose.connect("mongodb://localhost/ask");
const db = mongoose.connection;
//是否打开数据库成功
db.on("open",() => {
    console.log("打开数据库成功!");
})
//users集合  
const User = mongoose.model("user",{
    name: String,
    password: String,
    isMale: Boolean,
    email: String,
    time: Number,
    ip: String,
    photo: String,
    info: String
})

const Question = mongoose.model("question",{
    //文本内容
    text: String,
    //提问者
    createUser: {
        type:"ObjectId",
        ref:"user"
    },
    time: Number,
    ip: String,
    answer: [{
        type:"ObjectId",
        ref:"answer"
    }]
})

const Answer = mongoose.model("answer",{
    //文本内容
    text: String,
    question: String,
    createUser: {
        type:"ObjectId",
        ref:"user"
    },
    time: Number,
    ip: String
})

module.exports.User = User;
module.exports.Question = Question;
module.exports.Answer = Answer;