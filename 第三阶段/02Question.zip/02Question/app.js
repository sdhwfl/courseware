const express = require('express'),
  	  bodyParser = require('body-parser'),
  	  upload = require('./multer.js'),
  	  cookieParser = require('cookie-parser'),
  	  template = require('./template.js'),
  	  public = require('./public.js'),
  	  fs = require('fs'),
	  db = require('./db/db.js'),
  	  app = express();

app.use(express.static('www'));
app.engine(".html",template.__express);
app.set("view engine","html");
app.set('views',__dirname + '/www');

app.use(require('./routers/index.js'));
app.use(require('./routers/login.js'));
app.use(require('./routers/reg.js'));
app.use(require('./routers/ask.js'));
app.use(require('./routers/answer.js'));
app.use(require('./routers/upload.js'));


app.use(bodyParser.urlencoded({ extended: true }));

app.use(cookieParser());





app.listen(3000, () => {
  console.log('服务器正常起动');
})
