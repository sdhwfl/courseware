$(function() {
  var name = $.cookie("name");
  console.log(name);
  if (name) {
    $(".user-name").html('<span class="glyphicon glyphicon-user"></span>' + name).addClass("online");
  } else {
    $(".user-name").html('<span class="glyphicon glyphicon-user"></span>登陆');
  }
  // 控制用户下拉，如果同有登陆跳登陆页面
  $("body").on("click", ".user-name", function() {
    if ($(this).hasClass("online")) {
      $(".user-info").css({
        top: 50 + "px",
        right: -7 + "px"
      });
      $(".user-info").slideToggle();
    } else {
      location.href = "/user/login";
    }
  });
  $(".user-info a:first-child").click(function() {
    location.href = "/user/upload";
  });
  $(".user-info a:last-child").click(function(event) {
    $.cookie("name", name, {
      expires: -1
    });
    $.popup("退出成功", function() {
      location.href = "/";
    });
  });
  // 提问跳转
  $(".asksrc").click(function() {
    if (name) {
      location.href = "/ask"
    } else {
      location.href = "/user/login"
    }
  })

  // 点击某个问题事件
  $(".messages").on("click", ".ask", function(e) {
    // 获取问题的文件名
    var question = $(this).attr("data-id");
    console.log(question);
    // 把文件名写入cookie
    $.cookie("question", question,{path:'/'});
    // 跳转回答问题页面
    location.href = "/answer?question=" + question;
  });
  // 问答列表

});