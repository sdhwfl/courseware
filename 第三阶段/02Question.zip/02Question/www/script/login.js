$(function() {
  $("form").submit(function(ev) {
    ev.preventDefault();
    var data = $(this).serialize();
    $.post("/api/user/login", data, function(res, statusText) {
      if (statusText == "success") {
        console.log(res);
        if (res.code == "success") {
          $.cookie("name", res.data.name,{path:'/'});
          $.cookie("id", res.data.id,{path:'/'});
          $.popup(res.content, function() {
            location.href = "/"
          })
        } else {
          $.popup(res.content);
        }
      }
    })

  });
});