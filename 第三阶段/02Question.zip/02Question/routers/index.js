//导入express模块
var express = require("express");
//生成路由
var router = express.Router();

var fs = require("fs");

var db = require("../db/db.js");
//网站首页路由
router.get('/', (req, res) => {
  db.Question.find().populate("createUser").populate({path:'answer',populate:{path:'createUser',select:'-password'}}).exec(function (err, data) {
    
    data.reverse();
    
    res.render('demo', {
      title: "首页-问答系统",
      privateJs: "index.js",
      code: "success",
      data: data
    });
  })
//   fs.readdir("questions", (err, files) => {
//     var questions = [];
//     if (!err) {
//       // 倒序排列
//       files.reverse();
//       // console.log(files);
//       // 循环读出文件里内容加入questions数组里
//       files.forEach(function (file) {
//         fs.readFile("questions/" + file, (err, data) => {
//           if (!err) {
//             // console.log(data.toString())
//             questions.push(JSON.parse(data.toString()));
//             if (questions.length == files.length) {


//             }
//           }
//         });
//       });

//     }
//   })
})


module.exports = router;