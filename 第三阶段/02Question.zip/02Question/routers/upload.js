//导入express模块
var express = require("express");
//生成路由
var router = express.Router();
var public = require('../public.js');
var upload = require('../multer.js');
var db = require('../db/db.js');

router.get('/user/upload',public.isLogin,(req,res) =>{
	res.render("upload",{
		title:"上传头像-问答系统",
		privateJs:"upload.js"
	})
})

// 用户上传头像
router.post('/api/user/photo', upload.single("photo"), (req, res) => {
    
    res.status(200).json({ code: "success", content: "上传头像成功！" })
  
});

module.exports = router;