//导入express模块
var express = require("express");
//生成路由
var router = express.Router();
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var fs = require("fs");
var public = require('../public.js');
var db = require("../db/db.js");
router.use(bodyParser.urlencoded({ extended: true }));
router.use(cookieParser());
router.get('/answer',public.isLogin,(req,res) => {
	res.render("answer",{
		title:"回答-问答系统",
		privateJs:"answer.js"
	})
})

// 用户回答问题
router.post('/api/user/answer', (req, res) => {
  // 回答的对象
  var answer = {};
  answer.text = req.body.content;
  answer.question = req.cookies.question;
  answer.ip = req.ip;
  answer.time = new Date().getTime();
  answer.createUser = req.cookies.id;
  // console.log(answer.question);

 new db.Answer(answer).save(function(err,data){
   var id = answer.question;
   var answerId = {$push:{answer:data.id}};
   if(!err){
     db.Question.findByIdAndUpdate(id, answerId, function (err, data) {
       if(!err){
         console.log("回答更新成功");
         res.status(200).json({ code: "success", content: "回答问题成功！" })
       }else{
         console.log("回答问题失败");
       }
     })
      // res.status(200).json({ code: "success", content: "回答问题成功！" });
   }
 })
  // fs.readFile("questions/" + answer.question + ".txt", (err, data) => {
  //   if (!err) {
  //     //问题的对象
  //     var askObj = JSON.parse(data.toString());
  //     if ((typeof askObj.answer) == "object") {
  //       askObj.answer.push(answer);
  //     } else {
  //       askObj.answer = [];
  //       askObj.answer.push(answer);
  //     }
  //     fs.writeFile("questions/" + answer.question + ".txt", JSON.stringify(askObj), (err) => {
  //       if (!err) {
  //         res.status(200).json({ code: "success", content: "回答问题成功！" })
  //       }
  //     })
  //   }
  // })
});
module.exports = router;