//导入express模块
var express = require("express");
//生成路由
var router = express.Router();
var bodyParser = require('body-parser');
var fs = require("fs");
var db = require("../db/db.js");
router.use(bodyParser.urlencoded({ extended: true }));
router.get('/user/login', (req, res) => {
  res.render("login", {
    title: "登录-问答系统",
    privateJs: "login.js"
  })
})

// 用户登陆
router.post('/api/user/login', (req, res) => {
  var user = req.body;
  db.User.find({ name: user.name }, function (err, data) {
    if (!err) {
      if (data.length > 0) {
        if (user.password == data[0].password) {
          user.id = data[0].id;
          res.status(200).json({ code: "success", content: "登陆成功！", data: user })
        } else {
          res.status(200).json({ code: "error", content: "用户名或密码不正确！" })
        }
      } else {
        console.log("用户名不存在")
        res.status(200).json({ code: "error", content: "用户名不存在！" })
      }
    }
  });
});
module.exports = router;