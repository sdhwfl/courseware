//导入express模块
var express = require("express");
//生成路由
var router = express.Router();
var bodyParser = require('body-parser');
var fs = require("fs");
var db = require("../db/db.js");

router.use(bodyParser.urlencoded({ extended: true }));

router.get('/user/register', (req, res) => {
  res.render("register", {
    title: "注册-问答系统",
    privateJs: "reg.js"
  })
})

// 用户注册
router.post('/api/user/register', (req, res) => {
  // 增加ip
  req.body.ip = req.ip;
  // 增加时间
  req.body.time = new Date().getTime();
  // 注册用户对象
  var user = req.body;
  if (user.password == user.password01) {
    // 删除一个
    delete user.password01;
    console.log(user);

    db.User.find({ name: user.name }, function (err, data) {
      if (!err) {
        if (data.length > 0) {
          res.status(200).json({ "code": "error", "content": "用户名已存在！" });
        } else {
          // 写入数据库
          new db.User(user).save(function (err) {
            if (!err) {
              res.status(200).json({ "code": "success", "content": "恭喜，注册成功！" });
            } else {
            }
          });
        }
      }
    });
 } else {
    res.status(200).json({ "code": "error", "content": "密码输入不致！" });
  }
});
module.exports = router;