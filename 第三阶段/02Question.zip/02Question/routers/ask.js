//导入express模块
var express = require("express"),
//生成路由
    router = express.Router(),
    public = require('../public.js'),
    bodyParser = require('body-parser'),
    cookieParser = require('cookie-parser'),
    fs = require("fs"),
    db = require("../db/db.js");

router.use(bodyParser.urlencoded({ extended: true }));

router.use(cookieParser());
router.get('/ask',public.isLogin,(req,res) => {
	res.render("ask",{
		title:"提问-问答系统",
		privateJs:"ask.js"
	})
})

// 用户提交问题
router.post('/api/user/ask', (req, res) => {
  // console.log(req.body);
  var question = {};
  // 格式ip的
  function formatIp(val) {
    // ::ffff:192.168.3.251
    // ::1
    val = val == "::1" ? "192.168.0.1" : val;
    if (val.startsWith("::ffff:")) {
      val = val.substr(7);
    }
    return val;
  }
  question.text = req.body.content;
  question.createUser = req.cookies.id;
  question.ip = formatIp(req.ip);
  question.time = new Date().getTime();
  var txtName = question.time + ".txt";

  new db.Question(question).save(function(err){
    if(!err){
      res.status(200).json({ code: "success", content: "提问成功！" })
    }
  })
  
});

module.exports = router;