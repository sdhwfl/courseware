//是否登录
function isLogin(req,res,next){
	var name = req.cookies.name;
	if(name){
		next();
	}else{
		console.log('请登录')
		res.redirect("/user/login");
	}
}

function first(){
	
}

var funObj = {
	isLogin:isLogin
}

module.exports = funObj;